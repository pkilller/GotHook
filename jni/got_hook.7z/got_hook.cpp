#include <jni.h>
#include <stdio.h>
#include <stdlib.h>
#include <android/log.h>
#include <linux/elf.h>

#define  LOG_TAG    "got_hook"
#define  logcat(...)  __android_log_print(ANDROID_LOG_DEBUG,LOG_TAG,__VA_ARGS__)

typedef unsigned char byte;
typedef unsigned int size_t;
size_t fread(void * __restrict, size_t, size_t, FILE * __restrict);

void* find_self_module();
void* find_module(const char *p_module_name);
Elf32_Dyn* get_dynamic_table();
void* get_table_from_dynt(Elf32_Dyn *p_dynamic_table, Elf32_Sword tag);
bool set_hook(const char *psz_symbol, void *p_callback);

JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void *reserved)
{
	logcat("JNI_OnLoad()");
	//find_module("got_hook");
	set_hook("fopen", NULL);
	return JNI_VERSION_1_4;
}

void* find_self_module()
{
	byte *p = (byte*)find_self_module;
	p = (byte*)((unsigned int)p & 0xFFFFF000);
	byte elf_ident[] = {0x7F,0x45,0x4C,0x46};
	while(*(unsigned int*)p != *(unsigned int*)&elf_ident)
	{
		//logcat("cur: %p  *cur: %x", p, *(unsigned int*)p);
		p -= 0x1000;
	}
	//logcat("self base: %p", p);
	return (void*)p;
}

void* find_module(const char *psz_module_name)
{
	FILE *pf = fopen("/proc/self/maps", "r");
	char sz_line[0x500];
	while(0==feof(pf))
	{
		if ( fgets( sz_line, sizeof(sz_line), pf ) )
		{
			// logcat("read line:%s", sz_line);
			if ( strstr(sz_line, psz_module_name ) )
			{
				sz_line[8] = '\0';
				void *p = (void*)strtoul(sz_line, NULL, 16);
				//logcat("main base: %p", p);
				return p;
			}
		}
	}

	return NULL;
}

Elf32_Dyn* get_dynamic_table( const char *psz_module_name )
{
	//"/system/bin/app_process"
	void *pMainBase = find_module( psz_module_name );
	if ( pMainBase == NULL)
	{
		return NULL;
	}
	logcat("get_dynamic_table step: 1");
	Elf32_Ehdr *p_header = (Elf32_Ehdr*)pMainBase;
	Elf32_Phdr *p_program_header = (Elf32_Phdr*)( (unsigned int)pMainBase + p_header->e_phoff );
	Elf32_Half program_header_count = p_header->e_phnum;
	Elf32_Dyn *p_dynamic_table = NULL;
	logcat("get_dynamic_table step: 2");
	for ( int i = 0; i < program_header_count; i++ )
	{
		logcat("get_dynamic_table step: 3, dynamic: %p", p_program_header);
		if ( p_program_header[i].p_type == PT_DYNAMIC )
		{
			logcat("get_dynamic_table step: 4");
			p_dynamic_table = (Elf32_Dyn*)p_program_header[i].p_vaddr;
			logcat( "DynTalbe:%p\r\n", p_dynamic_table );
			return (Elf32_Dyn*)p_dynamic_table;
		}
	}
	return NULL;
}

const char* get_inerp( const char *psz_module_name )
{
	void *pMainBase = find_module( psz_module_name );
	if ( pMainBase == NULL)
	{
		return NULL;
	}
	logcat("main base: %p", pMainBase);
	Elf32_Ehdr *p_header = (Elf32_Ehdr*)pMainBase;
	Elf32_Phdr *p_program_header = (Elf32_Phdr*)( (unsigned int)pMainBase + p_header->e_phoff );
	Elf32_Half program_header_count = p_header->e_phnum;

	for ( int i = 0; i < program_header_count; i++ )
	{
		if ( p_program_header[i].p_type == PT_INTERP )
		{
			return (const char*)p_program_header[i].p_vaddr;
		}
	}
	return NULL;
}
void* get_table_from_dynt(Elf32_Dyn *p_dynamic_table, Elf32_Sword tag)
{
	while ( p_dynamic_table->d_tag != 0 )
	{
		if ( p_dynamic_table->d_tag == tag )
		{
			return (void*)p_dynamic_table->d_un.d_ptr;
		}
		p_dynamic_table ++;
	}
	return NULL;
}

// ELF Hash Function
Elf32_Sword elf_hash(const char *str)
{
    unsigned int hash = 0;
    unsigned int x = 0;

    while (*str)
    {
        hash = (hash << 4) + (*str++);
        if ((x = hash & 0xF0000000L) != 0)
        {
            hash ^= (x >> 24);
            hash &= ~x;
        }
    }
    //����һ������λΪ0���������������λ�����⺯�������Ӱ�졣(���ǿ��Կ��ǣ����ֻ���ַ�������λ������Ϊ��)
    return (hash & 0x7FFFFFFF);
}

bool set_hook(const char *psz_symbol, void *p_callback)
{
	char *psz_main_module = "/system/bin/app_process";

	// inerp
	//const char *psz_linker = (const char*) get_inerp( psz_main_module );

	//logcat( "linker: %s", psz_linker );

	Elf32_Dyn *p_dynamic_table = get_dynamic_table( psz_main_module );

	//logcat( "%s dynamic: %p", psz_linker, p_dynamic_table );

	// symbol table
	Elf32_Sym *p_symbol_table = (Elf32_Sym*) get_table_from_dynt( p_dynamic_table, DT_SYMTAB );

	// str table
	const char *p_str_table = (const char*) get_table_from_dynt( p_dynamic_table, DT_STRTAB );

	// hash table
	Elf32_Sword *p_hash_table = (Elf32_Sword*) get_table_from_dynt( p_dynamic_table, DT_HASH );
	Elf32_Sword hash_bucket_count = *( p_hash_table+0 );
	Elf32_Sword hash_chine_count = *( p_hash_table+1 );
	Elf32_Sword *p_hash_bucket = p_hash_table+2;
	Elf32_Sword *p_hash_chine = p_hash_table+2+hash_bucket_count;
	logcat( "hash_table: %d %d %p %p", hash_bucket_count, hash_chine_count, p_hash_bucket, p_hash_chine );


	Elf32_Sword symb_hash = elf_hash( psz_symbol );
	int hash_index = symb_hash % hash_bucket_count;
	int symb_index = p_hash_bucket[hash_index];
	Elf32_Addr str_table_offset = p_symbol_table[symb_index].st_name;
	const char *pcurstr = p_str_table + str_table_offset;
	bool is_hit = false;
	if (strcmp(pcurstr, psz_symbol) == 0)
	{
		logcat("hit chine printf");
		is_hit = true;
	}
	else
	{
		// δ����, ������ײ
		int chine_index = symb_index;
		while(chine_index < hash_chine_count && chine_index != 0)
		{
			symb_index = p_hash_chine[chine_index];
			str_table_offset = p_symbol_table[symb_index].st_name;
			pcurstr = p_str_table + str_table_offset;
			logcat("str: %s", pcurstr);
			if ( strcmp(pcurstr, psz_symbol) == 0 )
			{
				logcat("hit chine");
				is_hit = true;
				break;
			}
			chine_index = symb_index;
		}
	}
	if ( !is_hit )
	{
		return false;
	}


	logcat("end ");


	return true;
}
